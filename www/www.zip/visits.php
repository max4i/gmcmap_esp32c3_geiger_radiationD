<?php
$logFile = 'visit_log.txt';
$currentIP = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$currentTime = time();
$timeout = 300; // 30 minut w sekundach

// Odczytaj istniejące dane
$total = 0;
$unique = [];
$today = 0;
$recentVisits = [];

if (file_exists($logFile)) {
    $lines = file($logFile, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
        $total++;
        $parts = explode('|', $line);
        if (count($parts) >= 2) {
            $ip = $parts[1];
            $timestamp = $parts[0];
            $visitDate = $parts[3] ?? '';
            
            // Sprawdź czy wizyta była dzisiaj
            if (strpos($visitDate, date('Y-m-d')) === 0) {
                $today++;
            }
            
            // Sprawdź czy IP jest unikalne w ciągu ostatnich 30 minut
            if ($currentTime - intval($timestamp) <= $timeout) {
                $recentVisits[$ip] = $timestamp;
            }
            
            // Zliczanie całkowicie unikalnych IP (bez limitu czasu)
            if (!in_array($ip, $unique)) {
                $unique[] = $ip;
            }
        }
    }
}

// Sprawdź czy bieżące IP ma wizytę w ciągu ostatnich 30 minut
$isUniqueRecentVisit = true;
if (isset($recentVisits[$currentIP])) {
    $lastVisitTime = $recentVisits[$currentIP];
    if ($currentTime - $lastVisitTime <= $timeout) {
        $isUniqueRecentVisit = false;
    }
}

// Zwiększ liczniki tylko jeśli to unikalna wizyta w ostatnich 30 minutach
if ($isUniqueRecentVisit) {
    $total++;
    $today++;
    
    // Zapisz nowy wpis tylko dla unikalnej wizyty
    $entry = $currentTime . '|' . $currentIP . '|' . 
             ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown') . '|' . 
             date('Y-m-d H:i:s') . "\n";
    file_put_contents($logFile, $entry, FILE_APPEND);
    
    // Dodaj IP do listy unikalnych jeśli jeszcze go tam nie ma
    if (!in_array($currentIP, $unique)) {
        $unique[] = $currentIP;
    }
}

// Przygotuj statystyki
$recentUniqueCount = count($recentVisits);
if ($isUniqueRecentVisit && !isset($recentVisits[$currentIP])) {
    $recentUniqueCount++;
}

// Wyświetl statystyki
// Format: [unikalne w ciągu 30 minut] / [unikalne ogólnie] / [całkowita liczba wizyt]
echo $recentUniqueCount . '/' . count($unique) . '/' . $total;
?>