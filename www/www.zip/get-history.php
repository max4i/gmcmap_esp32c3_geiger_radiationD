<?php
// get-history.php - SUPER PROSTA WERSJA
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$file = 'data/radiation_history.json';

// Sprawdź czy plik istnieje
if (!file_exists($file)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Plik nie istnieje: ' . $file,
        'data' => []
    ]);
    exit;
}

try {
    // Odczytaj plik
    $content = file_get_contents($file);
    
    if ($content === false) {
        echo json_encode([
            'status' => 'error', 
            'message' => 'Nie można odczytać pliku',
            'data' => []
        ]);
        exit;
    }
    
    // Sprawdź czy nie jest pusty
    if (trim($content) === '') {
        echo json_encode([
            'status' => 'success',
            'message' => 'Plik jest pusty',
            'data' => [],
            'count' => 0
        ]);
        exit;
    }
    
    // Parsuj JSON
    $data = json_decode($content, true);
    
    if ($data === null) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Nieprawidłowy JSON: ' . json_last_error_msg(),
            'data' => []
        ]);
        exit;
    }
    
    // Upewnij się, że to tablica
    if (!is_array($data)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Dane nie są tablicą',
            'data' => []
        ]);
        exit;
    }
    
    // Filtruj dane z ostatnich 24h (opcjonalnie)
    $hours = isset($_GET['hours']) ? intval($_GET['hours']) : 24;
    $cutoff = time() - ($hours * 3600);
    
    $filteredData = [];
    foreach ($data as $item) {
        if (isset($item['timestamp']) && $item['timestamp'] >= $cutoff) {
            $filteredData[] = $item;
        }
    }
    
    // Odpowiedź
    echo json_encode([
        'status' => 'success',
        'message' => 'OK',
        'data' => $filteredData,
        'total_count' => count($data),
        'filtered_count' => count($filteredData),
        'hours' => $hours
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Exception: ' . $e->getMessage(),
        'data' => []
    ]);
}
?>