<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Only POST method allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON data']);
    exit;
}

$host = 'localhost';
$dbname = 'geiger_db';
$username = 'username';
$password = 'password';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Przygotuj dane
    $timestamp = $input['timestamp'] ?? time();
    $radiation_usv = $input['radiation']['usv_h'] ?? 0;
    $radiation_cpm = $input['radiation']['cpm'] ?? 0;
    $radiation_acpm = $input['radiation']['acpm'] ?? 0;
    $radiation_stability = $input['radiation']['stability'] ?? 0;
    
    $temperature = $input['environment']['temperature'] ?? null;
    $humidity = $input['environment']['humidity'] ?? null;
    $pressure = $input['environment']['pressure'] ?? null;
    
    // Wstaw dane
    $stmt = $pdo->prepare("
        INSERT INTO geiger_data 
        (timestamp, radiation_usv, radiation_cpm, radiation_acpm, radiation_stability, 
         temperature, humidity, pressure, created_at)
        VALUES 
        (:timestamp, :radiation_usv, :radiation_cpm, :radiation_acpm, :radiation_stability,
         :temperature, :humidity, :pressure, NOW())
    ");
    
    $stmt->execute([
        ':timestamp' => $timestamp,
        ':radiation_usv' => $radiation_usv,
        ':radiation_cpm' => $radiation_cpm,
        ':radiation_acpm' => $radiation_acpm,
        ':radiation_stability' => $radiation_stability,
        ':temperature' => $temperature,
        ':humidity' => $humidity,
        ':pressure' => $pressure
    ]);
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Data saved successfully',
        'id' => $pdo->lastInsertId()
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>