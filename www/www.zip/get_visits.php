<?php
$log_file = 'visit_log.txt';
$timeout_24h = 24 * 60 * 60;
$timeout_7d = 7 * 24 * 60 * 60;

// Odczytaj historię
$visits = [];
if (file_exists($log_file)) {
    $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $parts = explode('|', $line);
        if (count($parts) >= 4) {
            $visits[] = [
                'timestamp' => (int)$parts[0],
                'ip' => $parts[1],
                'user_agent' => $parts[2],
                'date' => $parts[3]
            ];
        }
    }
}

// Oblicz unikalne wizyty
function countUniqueVisits($visits, $timeout) {
    $now = time();
    $unique_ips = [];
    $count = 0;
    
    foreach ($visits as $visit) {
        if ($now - $visit['timestamp'] <= $timeout) {
            if (!in_array($visit['ip'], $unique_ips)) {
                $unique_ips[] = $visit['ip'];
                $count++;
            }
        }
    }
    
    return $count;
}

$total_visits = count($visits);
$visits_24h = countUniqueVisits($visits, $timeout_24h);
$visits_7d = countUniqueVisits($visits, $timeout_7d);

// Zwróć dane jako JSON
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
echo json_encode([
    'status' => 'success',
    'total' => $total_visits,
    'last24h' => $visits_24h,
    'last7d' => $visits_7d,
    'timestamp' => time()
]);
?>