<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Tylko POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Tylko metoda POST']);
    exit;
}

// Odczytaj dane
$input = json_decode(file_get_contents('php://input'), true);
$password = $input['password'] ?? '';
$what = $input['what'] ?? 'all'; // all, history, current

// Hasło - ZMIENIJ TO!
$correct_password = '1234567890'; // <-- ZMIEŃ TO NA SWOJE HASŁO!

if ($password !== $correct_password) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Nieprawidłowe hasło'
    ]);
    exit;
}

$results = [];

// 1. Reset pliku historii
if ($what === 'all' || $what === 'history') {
    $historyFile = 'data/radiation_history.json';
    if (file_exists($historyFile)) {
        file_put_contents($historyFile, json_encode([], JSON_PRETTY_PRINT));
        $results[] = 'Plik historii wyczyszczony';
    } else {
        $results[] = 'Plik historii nie istnieje';
    }
}

// 2. Reset aktualnych danych
if ($what === 'all' || $what === 'current') {
    $currentFile = 'geiger-view.json';
    if (file_exists($currentFile)) {
        file_put_contents($currentFile, json_encode([
            'error' => 'Dane zresetowane, oczekiwanie na nowe odczyty',
            'reset_at' => date('Y-m-d H:i:s'),
            'reset_by' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ], JSON_PRETTY_PRINT));
        $results[] = 'Aktualne dane zresetowane';
    } else {
        $results[] = 'Plik aktualnych danych nie istnieje';
    }
}

// 3. Reset dodatkowych plików (opcjonalnie)
if ($what === 'all') {
    // Możesz dodać inne pliki do czyszczenia
    $backupDir = 'data/backups/';
    if (is_dir($backupDir)) {
        // Możesz tu czyścić backup jeśli chcesz
        // $results[] = 'Backupy wyczyszczone';
    }
}

echo json_encode([
    'status' => 'success',
    'message' => 'Reset wykonany pomyślnie',
    'details' => $results,
    'timestamp' => time(),
    'timestamp_str' => date('Y-m-d H:i:s')
]);
?>