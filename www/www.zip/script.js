// Główne zmienne
let currentData = null;
let historyData = [];
let updateInterval = 10 * 60 * 1000; // 10 minut domyślnie (w milisekundach)
let nextUpdateTime = null;
let charts = {
    radiation: null,
    tempHumidity: null,
    pressure: null
};

// Elementy DOM
const elements = {
    radiationValue: document.getElementById('radiationValue'),
    radiationLevel: document.getElementById('radiationLevel'),
    dailyDose: document.getElementById('dailyDose'),
    cpmCurrent: document.getElementById('cpmCurrent'),
    cpmAvg: document.getElementById('cpmAvg'),
    stability: document.getElementById('stability'),
    stabilityBar: document.getElementById('stabilityBar'),
    temperature: document.getElementById('temperature'),
    humidity: document.getElementById('humidity'),
    pressure: document.getElementById('pressure'),
    iaqScore: document.getElementById('iaqScore'),
    iaqLevel: document.getElementById('iaqLevel'),
    iaqBar: document.getElementById('iaqBar'),
    alarmCircle: document.getElementById('alarmCircle'),
    location: document.getElementById('location'),
    connectionStatus: document.getElementById('connectionStatus'),
    statusText: document.getElementById('statusText'),
    lastUpdate: document.getElementById('lastUpdate'),
    nextUpdate: document.getElementById('nextUpdate'),
    systemTimestamp: document.getElementById('systemTimestamp'),
    refreshBtn: document.getElementById('refreshBtn'),
    dewPoint: document.getElementById('dewPoint'),
    heatIndex: document.getElementById('heatIndex'),
    co2eq: document.getElementById('co2eq'),
    airDensity: document.getElementById('airDensity'),
    gasResistance: document.getElementById('gasResistance'),
    absHumidity: document.getElementById('absHumidity'),
    voceq: document.getElementById('voceq')
};

// Inicjalizacja przy ładowaniu strony
document.addEventListener('DOMContentLoaded', function() {
    // Rejestracja wizyty
    registerVisit();
    
    // Ładowanie danych początkowych
    loadCurrentData();
    loadHistoryData();
    
    // Inicjalizacja wykresów
    initializeCharts();
    
    // Ustawienie odświeżania cyklicznego
    setupAutoRefresh();
    
    // Obsługa przycisku odświeżania
    elements.refreshBtn.addEventListener('click', function() {
        forceRefresh();
    });
    
    // Obsługa statusu online/offline
    window.addEventListener('online', updateConnectionStatus);
    window.addEventListener('offline', updateConnectionStatus);
    updateConnectionStatus();
});

// Rejestracja wizyty
function registerVisit() {
    fetch('visits.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'register' })
    })
    .catch(error => console.error('Błąd rejestracji wizyty:', error));
}

// Ładowanie bieżących danych
async function loadCurrentData() {
    try {
        const response = await fetch('geiger-view.json');
        if (!response.ok) throw new Error('Błąd sieci');
        
        const data = await response.json();
        currentData = data;
        updateDisplay(data);
        updateChartsWithCurrentData(data);
        
        // Aktualizacja interwału odświeżania
        if (data.update_interval_minutes) {
            updateInterval = data.update_interval_minutes * 60 * 1000;
        }
        
        // Ustawienie czasu następnej aktualizacji
        const now = new Date();
        nextUpdateTime = new Date(now.getTime() + updateInterval);
        updateNextUpdateTime();
        
        // Aktualizacja statusu połączenia
        updateConnectionStatus(true);
        
    } catch (error) {
        console.error('Błąd ładowania danych:', error);
        updateConnectionStatus(false);
        
        // Fallback - użyj domyślnych danych
        const fallbackData = getFallbackData();
        updateDisplay(fallbackData);
    }
}

// Ładowanie danych historycznych
async function loadHistoryData() {
    try {
        const response = await fetch('get-history.php');
        if (!response.ok) throw new Error('Błąd sieci');
        
        const data = await response.json();
        historyData = data;
        updateChartsWithHistory(data);
        
    } catch (error) {
        console.error('Błąd ładowania historii:', error);
    }
}

// Aktualizacja wyświetlaczy
function updateDisplay(data) {
    if (!data) return;
    
    // Walidacja i formatowanie danych
    const radiation = validateRadiation(data.radiation?.usv_h || 0);
    const temp = validateEnvironmental(data.environment?.temperature, '--°C');
    const humidity = validateEnvironmental(data.environment?.humidity, '--%');
    
    // Poziom promieniowania
    elements.radiationValue.textContent = radiation.toFixed(4);
    elements.dailyDose.textContent = (data.radiation?.daily_dose || 0).toFixed(6) + ' µSv';
    
    // Ustawienie koloru i poziomu promieniowania
    updateRadiationLevel(radiation);
    
    // Impulsy
    elements.cpmCurrent.textContent = (data.radiation?.cpm || 0).toFixed(1);
    elements.cpmAvg.textContent = (data.radiation?.acpm || 0).toFixed(1);
    elements.stability.textContent = (data.radiation?.stability || 0).toFixed(1) + '%';
    elements.stabilityBar.style.width = (data.radiation?.stability || 0) + '%';
    
    // Środowisko
    elements.temperature.textContent = temp;
    elements.humidity.textContent = humidity;
    elements.pressure.textContent = (data.environment?.pressure || 0).toFixed(1) + ' hPa';
    
    // Jakość powietrza
    const iaq = data.environment?.iaq_score || 0;
    elements.iaqScore.textContent = iaq.toFixed(1);
    elements.iaqLevel.textContent = data.environment?.iaq_level || 'BRAK DANYCH';
    elements.iaqBar.style.width = Math.min(iaq, 100) + '%';
    
    // Ustawienie koloru paska jakości powietrza
    if (iaq >= 80) elements.iaqBar.className = 'progress-fill bg-green-500';
    else if (iaq >= 60) elements.iaqBar.className = 'progress-fill bg-yellow-500';
    else if (iaq >= 40) elements.iaqBar.className = 'progress-fill bg-orange-500';
    else elements.iaqBar.className = 'progress-fill bg-red-500';
    
    // Dodatkowe dane środowiskowe
    elements.dewPoint.textContent = (data.environment?.dew_point || 0).toFixed(1) + '°C';
    elements.heatIndex.textContent = (data.environment?.heat_index || 0).toFixed(1) + '°C';
    elements.co2eq.textContent = (data.environment?.co2_equivalent || 0) + ' ppm';
    elements.airDensity.textContent = (data.environment?.air_density || 0).toFixed(3) + ' kg/m³';
    elements.gasResistance.textContent = ((data.environment?.gas_resistance || 0) / 1000).toFixed(1) + ' kΩ';
    elements.absHumidity.textContent = (data.environment?.absolute_humidity || 0).toFixed(1) + ' g/m³';
    elements.voceq.textContent = (data.environment?.voc_equivalent || 0).toFixed(2) + ' ppm';
    
    // Lokalizacja
    if (data.metadata?.location) {
        elements.location.textContent = data.metadata.location;
    }
    
    // Timestamp systemu
    if (data.timestamp) {
        const date = new Date(data.timestamp * 1000);
        elements.systemTimestamp.textContent = date.toLocaleString('pl-PL');
        elements.lastUpdate.textContent = date.toLocaleTimeString('pl-PL');
    }
}

// Aktualizacja poziomu promieniowania i koła alarmowego
function updateRadiationLevel(usvPerHour) {
    let level, color, circleClass, circleText;
    
    if (usvPerHour <= 2) {
        level = 'BRAK ZAGROŻENIA';
        color = '#00ff00';
        circleClass = 'safe';
        circleText = 'BRAK<br>ZAGROŻENIA';
    } else if (usvPerHour <= 10) {
        level = 'ŹLE';
        color = '#ffaa00';
        circleClass = 'warning';
        circleText = 'ŹLE<br>UWAGA';
    } else {
        level = 'SCHOWAJ SIĘ';
        color = '#ff0000';
        circleClass = 'danger';
        circleText = 'SCHOWAJ<br>SIĘ';
    }
    
    elements.radiationValue.style.color = color;
    elements.radiationLevel.textContent = level;
    elements.radiationLevel.style.color = color;
    
    // Aktualizacja koła alarmowego
    elements.alarmCircle.className = `status-circle ${circleClass}`;
    elements.alarmCircle.innerHTML = circleText.replace('<br>', '<br/>');
}

// Walidacja danych promieniowania
function validateRadiation(value) {
    if (value < 0.05) return 0;
    return value;
}

// Walidacja danych środowiskowych
function validateEnvironmental(value, fallback) {
    if (value === null || value === undefined || value === 0) return fallback;
    return value;
}

// Inicjalizacja wykresów
function initializeCharts() {
    // Wykres promieniowania
    const radiationCtx = document.getElementById('radiationChart').getContext('2d');
    charts.radiation = new Chart(radiationCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Poziom promieniowania (µSv/h)',
                data: [],
                borderColor: '#39ff14',
                backgroundColor: 'rgba(57, 255, 20, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'µSv/h'
                    },
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#e0e0e0'
                    }
                }
            }
        }
    });
    
    // Wykres temperatury i wilgotności
    const tempHumidityCtx = document.getElementById('tempHumidityChart').getContext('2d');
    charts.tempHumidity = new Chart(tempHumidityCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Temperatura (°C)',
                    data: [],
                    borderColor: '#ff4444',
                    backgroundColor: 'rgba(255, 68, 68, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    yAxisID: 'y'
                },
                {
                    label: 'Wilgotność (%)',
                    data: [],
                    borderColor: '#4488ff',
                    backgroundColor: 'rgba(68, 136, 255, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    min: -15,
                    max: 35,
                    title: {
                        display: true,
                        text: 'Temperatura (°C)'
                    },
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    min: 10,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Wilgotność (%)'
                    },
                    grid: {
                        drawOnChartArea: false
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#e0e0e0'
                    }
                }
            }
        }
    });
    
    // Wykres ciśnienia
    const pressureCtx = document.getElementById('pressureChart').getContext('2d');
    charts.pressure = new Chart(pressureCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Ciśnienie atmosferyczne (hPa)',
                data: [],
                borderColor: '#ffaa00',
                backgroundColor: 'rgba(255, 170, 0, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    min: 960,
                    max: 1030,
                    title: {
                        display: true,
                        text: 'hPa'
                    },
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(100, 100, 100, 0.2)'
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#e0e0e0'
                    }
                }
            }
        }
    });
}

// Aktualizacja wykresów danymi bieżącymi
function updateChartsWithCurrentData(data) {
    if (!data || !data.timestamp) return;
    
    const time = new Date(data.timestamp * 1000);
    const timeLabel = time.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
    
    // Aktualizacja wykresu promieniowania
    if (charts.radiation && data.radiation) {
        const radiation = validateRadiation(data.radiation.usv_h);
        updateChartData(charts.radiation, timeLabel, radiation, 24);
    }
    
    // Aktualizacja wykresu temperatury i wilgotności
    if (charts.tempHumidity && data.environment) {
        const temp = data.environment.temperature || null;
        const humidity = data.environment.humidity || null;
        
        updateChartData(charts.tempHumidity, timeLabel, [temp, humidity], 24, true);
    }
    
    // Aktualizacja wykresu ciśnienia
    if (charts.pressure && data.environment) {
        const pressure = data.environment.pressure || null;
        updateChartData(charts.pressure, timeLabel, pressure, 24);
    }
}

// Aktualizacja wykresów danymi historycznymi
function updateChartsWithHistory(history) {
    if (!history || history.length === 0) return;
    
    // Sortuj dane według czasu
    history.sort((a, b) => a.timestamp - b.timestamp);
    
    // Przygotuj dane dla wykresów
    const labels = [];
    const radiationData = [];
    const tempData = [];
    const humidityData = [];
    const pressureData = [];
    
    history.forEach(item => {
        const time = new Date(item.timestamp * 1000);
        labels.push(time.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }));
        
        radiationData.push(validateRadiation(item.radiation?.usv_h || 0));
        tempData.push(item.environment?.temperature || null);
        humidityData.push(item.environment?.humidity || null);
        pressureData.push(item.environment?.pressure || null);
    });
    
    // Aktualizuj wykresy
    if (charts.radiation) {
        charts.radiation.data.labels = labels;
        charts.radiation.data.datasets[0].data = radiationData;
        charts.radiation.update('none');
    }
    
    if (charts.tempHumidity) {
        charts.tempHumidity.data.labels = labels;
        charts.tempHumidity.data.datasets[0].data = tempData;
        charts.tempHumidity.data.datasets[1].data = humidityData;
        charts.tempHumidity.update('none');
    }
    
    if (charts.pressure) {
        charts.pressure.data.labels = labels;
        charts.pressure.data.datasets[0].data = pressureData;
        charts.pressure.update('none');
    }
}

// Pomocnicza funkcja do aktualizacji danych wykresu
function updateChartData(chart, label, data, maxPoints, isMultiDataset = false) {
    // Dodaj nową etykietę
    chart.data.labels.push(label);
    
    // Ogranicz liczbę punktów
    if (chart.data.labels.length > maxPoints) {
        chart.data.labels.shift();
    }
    
    // Dodaj dane
    if (isMultiDataset && Array.isArray(data)) {
        data.forEach((value, index) => {
            if (chart.data.datasets[index]) {
                chart.data.datasets[index].data.push(value);
                if (chart.data.datasets[index].data.length > maxPoints) {
                    chart.data.datasets[index].data.shift();
                }
            }
        });
    } else {
        chart.data.datasets[0].data.push(data);
        if (chart.data.datasets[0].data.length > maxPoints) {
            chart.data.datasets[0].data.shift();
        }
    }
    
    // Aktualizuj wykres
    chart.update('none');
}

// Ustawienie automatycznego odświeżania
function setupAutoRefresh() {
    setInterval(() => {
        loadCurrentData();
        loadHistoryData();
    }, updateInterval);
    
    // Timer do aktualizacji wyświetlacza czasu następnej aktualizacji
    setInterval(updateNextUpdateTime, 1000);
}

// Aktualizacja czasu następnej aktualizacji
function updateNextUpdateTime() {
    if (!nextUpdateTime) return;
    
    const now = new Date();
    const diff = nextUpdateTime - now;
    
    if (diff <= 0) {
        elements.nextUpdate.textContent = 'Teraz';
        nextUpdateTime = new Date(now.getTime() + updateInterval);
    } else {
        const minutes = Math.floor(diff / 60000);
        const seconds = Math.floor((diff % 60000) / 1000);
        elements.nextUpdate.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
}

// Wymuszone odświeżanie
function forceRefresh() {
    // Animacja przycisku
    const btn = elements.refreshBtn;
    btn.classList.add('refresh-btn');
    setTimeout(() => btn.classList.remove('refresh-btn'), 300);
    
    // Odśwież dane
    loadCurrentData();
    loadHistoryData();
    
    // Zresetuj timer następnej aktualizacji
    nextUpdateTime = new Date(new Date().getTime() + updateInterval);
}

// Aktualizacja statusu połączenia
function updateConnectionStatus(isOnline = null) {
    const online = isOnline !== null ? isOnline : navigator.onLine;
    
    if (online) {
        elements.connectionStatus.className = 'w-3 h-3 rounded-full bg-green-500 mr-2';
        elements.statusText.textContent = 'ONLINE';
        elements.statusText.className = 'font-bold text-green-400';
    } else {
        elements.connectionStatus.className = 'w-3 h-3 rounded-full bg-red-500 mr-2';
        elements.statusText.textContent = 'OFFLINE';
        elements.statusText.className = 'font-bold text-red-400';
    }
}

// Dane zastępcze na wypadek błędu
function getFallbackData() {
    const now = Math.floor(Date.now() / 1000);
    return {
        timestamp: now,
        radiation: {
            cpm: 25.5,
            acpm: 23.8,
            usv_h: 0.0700,
            daily_dose: 0.001000,
            stability: 75.0
        },
        environment: {
            temperature: 21.0,
            humidity: 50.0,
            pressure: 1013.0,
            gas_resistance: 40000,
            dew_point: 10.5,
            heat_index: 21.2,
            absolute_humidity: 9.0,
            air_density: 1.200,
            iaq_score: 80.0,
            iaq_level: 'DOBRA',
            co2_equivalent: 800,
            voc_equivalent: 3.50
        },
        metadata: {
            location: 'Tryb awaryjny'
        }
    };
}

// Modal dla stref zagrożenia
function openZoneModal(zoneNumber) {
    const modal = document.getElementById('zoneModal');
    const content = document.getElementById('modalContent');
    
    const zones = [
        {
            title: 'STREFA ZIELONA - BRAK ZAGROŻENIA',
            description: 'Poziom promieniowania ≤ 2 µSv/h. Normalny poziom promieniowania tła. Można przebywać na zewnątrz bez ograniczeń.',
            instructions: [
                'Normalna aktywność na zewnątrz',
                'Brak konieczności schronienia',
                'Monitoruj sytuację'
            ],
            color: 'green'
        },
        {
            title: 'STREFA ŻÓŁTA - PODWYŻSZONY POZIOM',
            description: 'Poziom promieniowania 2-10 µSv/h. Podwyższony poziom promieniowania. Zaleca się ograniczenie czasu przebywania na zewnątrz.',
            instructions: [
                'Ogranicz czas na zewnątrz do minimum',
                'Unikaj jedzenia na otwartym powietrzu',
                'Przygotuj schronienie'
            ],
            color: 'yellow'
        },
        {
            title: 'STREFA POMARAŃCZOWA - WYSOKI POZIOM',
            description: 'Poziom promieniowania 10-50 µSv/h. Wysoki poziom promieniowania. Konieczne schronienie w budynkach.',
            instructions: [
                'Natychmiast schroń się w budynku',
                'Zamknij okna i drzwi',
                'Włącz system filtracji powietrza',
                'Przygotuj się do ewakuacji'
            ],
            color: 'orange'
        },
        {
            title: 'STREFA CZERWONA - EKSTREMALNY POZIOM',
            description: 'Poziom promieniowania > 50 µSv/h. Ekstremalnie niebezpieczny poziom promieniowania. Konieczna natychmiastowa ewakuacja lub schronienie w specjalistycznych bunkrach.',
            instructions: [
                'Natychmiast schroń się w specjalistycznym schronie',
                'Jeśli to możliwe - ewakuuj się z terenu',
                'Użyj masek przeciwpyłowych',
                'Unikaj kontaktu z deszczem',
                'Słuchaj komunikatów służb'
            ],
            color: 'red'
        }
    ];
    
    const zone = zones[zoneNumber - 1];
    
    content.innerHTML = `
        <h2 class="text-2xl font-bold mb-4 text-center" style="color: ${zone.color}">
            ${zone.title}
        </h2>
        <img src="${zoneNumber}.jpg" alt="Strefa ${zoneNumber}" class="w-full h-64 object-cover rounded-lg mb-4">
        <p class="mb-6">${zone.description}</p>
        <h3 class="text-xl font-bold mb-3">ZALECENIA:</h3>
        <ul class="list-disc pl-5 space-y-2 mb-6">
            ${zone.instructions.map(inst => `<li>${inst}</li>`).join('')}
        </ul>
        <div class="text-center">
            <button onclick="closeZoneModal()" class="bg-gray-700 hover:bg-gray-800 text-white py-2 px-6 rounded-lg">
                Zamknij
            </button>
        </div>
    `;
    
    modal.style.display = 'block';
}

function closeZoneModal() {
    document.getElementById('zoneModal').style.display = 'none';
}

// Zamknij modal po kliknięciu poza nim
window.onclick = function(event) {
    const modal = document.getElementById('zoneModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}