<?php
// api_geiger.php
// Odbiera dowolny JSON z ESP32, zapisuje go do pliku geiger-view.json i dodaje do historii

header('Content-Type: application/json; charset=utf-8');

// tylko POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "POST only"]);
    exit;
}

// odczyt surowego body
$raw = file_get_contents("php://input");

if ($raw === false || trim($raw) === '') {
    http_response_code(400);
    echo json_encode(["error" => "Empty body"]);
    exit;
}

// próba dekodowania
$data = json_decode($raw, true);
if ($data === null) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON"]);
    exit;
}

// dodaj znacznik czasu serwera
$data['_server'] = [
    "received_at" => time(),
    "received_at_str" => date("Y-m-d H:i:s")
];

// zapisz CAŁY JSON jako aktualne dane
$currentFile = __DIR__ . '/geiger-view.json';
if (file_put_contents($currentFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) === false) {
    http_response_code(500);
    echo json_encode(["error" => "Cannot write to file"]);
    exit;
}

// ZAPISZ DO HISTORII (dodaj do tablicy)
$historyFile = __DIR__ . '/data/radiation_history.json';

// Utwórz folder data jeśli nie istnieje
if (!is_dir(__DIR__ . '/data')) {
    mkdir(__DIR__ . '/data', 0755, true);
}

$historyData = [];

// Jeśli plik historii istnieje, wczytaj dane
if (file_exists($historyFile)) {
    $existingContent = file_get_contents($historyFile);
    if ($existingContent && trim($existingContent) !== '') {
        $historyData = json_decode($existingContent, true);
        if (!is_array($historyData)) {
            $historyData = [];
        }
    }
}

// Ogranicz historię do ostatnich 720 próbek (12 godzin przy 1-minutowych interwałach)
if (count($historyData) >= 720) {
    $historyData = array_slice($historyData, -719); // Zostaw ostatnie 719 próbek
}

// Dodaj nowe dane do historii (tylko podstawowe dane dla oszczędności miejsca)
$historyEntry = [
    'timestamp' => $data['timestamp'] ?? time(),
    'radiation_usv_h' => $data['radiation']['usv_h'] ?? 0,
    'radiation_cpm' => $data['radiation']['cpm'] ?? 0,
    'temperature' => $data['environment']['temperature'] ?? null,
    'humidity' => $data['environment']['humidity'] ?? null,
    'pressure' => $data['environment']['pressure'] ?? null
];

$historyData[] = $historyEntry;

// Zapisz historię
if (file_put_contents($historyFile, json_encode($historyData, JSON_PRETTY_PRINT)) === false) {
    // Log error but don't fail - main data is saved
    error_log("Cannot write to history file: " . $historyFile);
}

// odpowiedź do ESP32
echo json_encode([
    "status" => "OK",
    "saved" => basename($currentFile),
    "history_entries" => count($historyData),
    "received_at" => $data['_server']['received_at_str']
]);
?>